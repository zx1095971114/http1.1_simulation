/*
 * @Author: your name
 * @Date: 2021-10-15 23:25:26
 * @LastEditTime: 2021-10-15 23:26:39
 * @LastEditors: Please set LastEditors
 * @Description: In User Settings Edit
 * @FilePath: \project-1-master\include\my_bool.h
 */

#ifndef MY_BOOL_H
#define MY_BOOL_H
#define TRUE 1
#define FALSE 0
typedef int bool;
#endif
